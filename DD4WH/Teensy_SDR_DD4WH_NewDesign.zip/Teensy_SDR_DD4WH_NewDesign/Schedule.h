// Example schedule
5900	BUL	english	EU NEWS	1845-1900
5905	CHN	russian	China R Int.	1400-1500
5905	CHN	english	Deutsche Welle	0300-0400


